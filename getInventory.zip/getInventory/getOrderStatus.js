var faker = require('@faker-js/faker').faker;

exports.handler = function(event, context){
  // return order details for a given order
  var order = {};
  // name, address, city, state, phone, order date, ship date, price, transaction type
  order.id = event.orderId;
  order.name = getName();
  order.address = getShippingAddress();
  order.city = getShippingCity();
  order.state = getShippingState();
  order.phone = getPhone();
  order.shipMethod = getShipMethod();
  order.price = getPrice();
  context.succeed(order);
}

function getName() {
  return faker.person.findName();
}

function getShippingAddress() {
  return faker.location.streetAddress();
}

function getShippingCity() {
  return faker.location.city();
}

function getShippingState() {
  return faker.location.state();
}

function getPhone() {
  return faker.phone.number();
}

function getShipMethod() {
  var shippers = ['FedEx', 'UPS', 'USPS', 'DHL']
  return shippers[Math.floor(Math.random() * 4)];
}

function getPrice() {
  return faker.commerce.price();
}

